import ray
from ray import serve
from fastapi import FastAPI, HTTPException
# import numpy as np


model = "your model"

app = FastAPI(debug=True)

# this decorator sets Ray Serve configurations
@serve.deployment(name="app_name",
				  ray_actor_options={"num_cpus": 0, "num_gpus": 0, "memory": 0},
				  autoscaling_config={"min_replicas": 1, "max_replicas": 1})  # , "resources": {"rasp":0.25}
@serve.ingress(app)
class Qoe:
	def __init__(self):
		self.model = model

	@app.post("/")
	async def qoe_prediction(self, data: dict):
		try:

			# convert data
			# instances = data.get("instances", [])
			# instances = np.array(instances, dtype=np.float32)

			# Perform prediction using your model
			# result = model.predict(instances)
			# print(result)

			# Return the prediction
			# return {"class_index": str(result)}

			return str(data) # testing example
		except Exception as e:
			raise HTTPException(status_code=500, detail=f"Error processing request: {str(e)}")

	@app.post("/test")
	def get(self):
		return "NAOMI Ray Serve Works!"

ray.init(address=f"ray://193.2.205.27:30001", ignore_reinit_error=True)
serve.run(Qoe.bind(), name="deployment_name", route_prefix="/")  # change route_prefix if needed
serve.delete("Test")  # placeholder removal
